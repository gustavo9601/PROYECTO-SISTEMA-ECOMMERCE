<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<title>Tienda Virtual</title>
</head>
<body>
	<h1>Titulo</h1>
</body>
</html>