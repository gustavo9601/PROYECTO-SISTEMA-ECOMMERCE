<?php


class ControladorPlantilla{

	public function plantilla(){

		include "vistas/plantilla.php";

	}

}